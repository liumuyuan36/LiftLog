# LiftLog V1.15.4 演示资料包

先解压，再打开 docs/demo-v1.15.4/LiftLog-v1.15.4-demo.mp4。
完整视频约 3 分 46 秒，20 个章节，含中文说明，无旁白。

- 中文说明：docs/demo-v1.15.4/README.md
- 独立字幕：docs/demo-v1.15.4/subtitles.srt
- 章节索引：docs/demo-v1.15.4/chapters.json
- 四次本地真实 Atlas 推理：docs/demo-v1.15.4/capture-evidence.json
- 轨迹动图和发布检查：docs/trail-v1.15.4/
- 校验清单：MANIFEST.json

全部使用隔离的示例数据；没有个人记录、密钥、浏览器配置或模型大权重。
源码：https://github.com/liumuyuan36/LiftLog
公开体验：https://modelscope.cn/studios/VermouthLau/liftlog?mode=full
